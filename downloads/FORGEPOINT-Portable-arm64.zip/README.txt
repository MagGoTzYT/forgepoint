# FORGEPOINT — PC Diagnostics & IT Workshop

A native Windows desktop application (Rust, egui/eframe, SQLite) for PC
technicians, repair shops, IT professionals and advanced home users.

See [`docs/STATUS.md`](docs/STATUS.md) for exactly what has been compiled,
tested and run, and [`docs/TROUBLESHOOTING.md`](docs/TROUBLESHOOTING.md) if
something goes wrong.

## Modules

| Module | What it does |
|--------|--------------|
| **Dashboard** | Health score, live CPU/memory charts, storage, uptime, hardware inventory, shortcuts |
| **Diagnostics** | 14 read-only hardware checks: system, BIOS/board, CPU, memory modules (+ Windows Memory Diagnostic launcher), GPUs, displays, drives with SMART when exposed, partitions, battery health, network adapters, USB, PCI, audio, peripherals |
| **Windows Health** | Version, activation, boot/uptime/Secure Boot, Windows Update state, Defender/firewall (read-only), crash and error summary, restore points, DISM CheckHealth, SFC verify-only; Event Viewer and settings shortcuts |
| **Repair Centre** | SFC scan, DISM check/scan/restore, component cleanup, Disk Cleanup, DNS flush, network info and test, Windows Update status and component reset, temp-file cleanup (scan then confirm), Recycle Bin, restore point creation |
| **Driver Workshop** | Driver inventory, problem devices with explanations, details, hardware IDs, CSV/JSON export, driver package backup (pnputil), Device Manager and Windows Update driver shortcuts |
| **IT Workshop** | Customers, devices and repair tickets: 9 statuses, search, history timeline, customer approvals, parts, work performed, attach this PC's diagnostics, "Add this PC" as a device, printable repair and job completion PDFs, JSON export/import |
| **Reports** | Choose sections; save as PDF, TXT, CSV or JSON |
| **Software & Startup** | Installed apps, startup items, live process viewer (end process with confirmation), services (start/stop/restart with confirmation); links to Windows uninstall and startup settings |
| **Network Workshop** | Step-by-step connection check explained in plain language, adapters with IP/gateway/DNS, ping, DNS lookup, Wi-Fi details |
| **Script Workshop** | PowerShell/CMD editor, templates, risk detection, preview and confirmation, stdout/stderr/exit code, cancel, history, save/load |
| **Activity Log** | Every action, filterable, exportable to CSV |
| **Settings** | Preferences, database backup and restore, data folders |

## Interface

A familiar Windows 11 dark look: neutral grey surfaces, rounded cards, Segoe UI
throughout, Windows' light-blue accent, sentence-case labels, a quiet status
bar (database, host, privileges, CPU/memory, uptime), a collapsible sidebar,
and a command palette: press **Ctrl+K** (or the command button in the top bar) to
jump to any page or run an action (new ticket, run checks, back up the
database…).

## Repositories, releases and website

| Repository | Visibility | Holds |
|------------|-----------|-------|
| `MagGoTzYT/forgepoint-source` | **Private** | This source code, CI |
| `MagGoTzYT/forgepoint` | Public | The website (GitHub Pages) and the release downloads only |

To publish a version, raise `version` in `Cargo.toml` and push to `main`.
The **Release** workflow tests and packages FORGEPOINT on a Windows runner,
writes `SHA256SUMS.txt`, and publishes the installer and zips as a release of
the public repository. The source code is never copied there.

It needs one repository secret, `RELEASES_TOKEN`: a fine-grained personal
access token with access to `MagGoTzYT/forgepoint` only and the permission
**Contents: Read and write**. Give it an expiry date and renew it when it
lapses. Never put the token in a file.

Website: <https://maggotzyt.github.io/forgepoint/>

## Safety principles

* Read-only diagnostics work without administrator rights.
* Anything that changes the system explains itself, shows the exact command,
  states whether it needs administrator rights, and asks for confirmation.
  Risky scripts need an extra "I understand" tick.
* FORGEPOINT never disables Windows Defender or the firewall, never stops core
  or security services, never ends critical Windows processes, never removes
  drivers automatically, never edits the registry silently, and never runs
  downloaded scripts.
* Temp cleanup deletes only the files it listed, never folders or recent files.
* Database restores keep a safety copy of the current database first.
* Customer data is minimal and stays in the local database.

## Building

Requirements: Rust stable 1.85+ and the MSVC build tools ("Desktop development
with C++", which includes the Windows SDK used to embed the icon).

```
cargo fmt
cargo test
cargo run --release
```

### Packaging

```
powershell -ExecutionPolicy Bypass -File scripts\package.ps1
```

produces in `dist\`:

* `x64\FORGEPOINT.exe`
* `FORGEPOINT-Portable-x64.zip` (runs without installing; data stays beside the exe)
* `FORGEPOINT-Setup-x64.exe` (needs [Inno Setup 6](https://jrsoftware.org/isinfo.php):
  `winget install JRSoftware.InnoSetup`). Start Menu shortcut, optional desktop
  shortcut, uninstaller; user data is kept across upgrades.

ARM64: `scripts\package.ps1 -Target aarch64-pc-windows-msvc -Arch arm64`
(requires `rustup target add aarch64-pc-windows-msvc`).

GitHub Actions (`.github/workflows/ci.yml`) builds, tests and packages x64, and
cross-compiles ARM64 and x86 (built, not run).

## Data locations

| Mode      | Location |
|-----------|----------|
| Installed | `%APPDATA%\Forgepoint\FORGEPOINT\data` |
| Portable  | `data\` beside `FORGEPOINT.exe`, enabled by a file named `portable.flag` next to the exe |

The database is `forgepoint.db`; logs are in `logs\`; safety copies made before
a restore are in `backups\`. Settings shows the exact paths and can open them.

## Tips

* `Ctrl+K` opens the command palette; `Ctrl+F` jumps to search (modules, customers, tickets).
* Run Diagnostics first: the dashboard, "Add this PC" and ticket diagnostics
  use its results.
* "Run as administrator" in the top bar unlocks the admin-only tools.
